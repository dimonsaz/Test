1. webserver testing:

Run applicaiton in local ISS (on http://localhost:61975)

� curl -H "Content-Length:0" -X POST http://localhost:61975/messages/hello
	"2CF24DBA5FB0A30E26E83B2AC5B9E29E1B161E5C1FA7425E73043362938B9824"%    

� curl http://localhost:61975/messages/2CF24DBA5FB0A30E26E83B2AC5B9E29E1B161E5C1FA7425E73043362938B9824                                       
	"hello"%            


2. Gift testing:

� ./Gift2.exe 
	command line args: <file_path> <max_cost>
� ./Gift2.exe prices.txt 4343                
	Earmuffs 2000, Headphones 1400
� ./Gift2.exe prices.txt 50                  
	Not possible.
� ./Gift2.exe prices.txt 5000                
	Earmuffs 2000, Headphones 1400
� ./Gift2.exe prices.txt 2100                
	Headphones 1400, Cook Book 700


3. Digit Combinations

� ./DigitCombinations.exe 01x00x01
01000001
01000101
01100001
01100101

� ./DigitCombinations.exe 01x00x010x11  
010000010011
010000010111
010001010011
010001010111
011000010011
011000010111
011001010011
011001010111
