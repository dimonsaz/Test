﻿namespace Gift2
{
    /// <summary>
    /// Gift
    /// </summary>
    internal class Gift
    {
        /// <summary>
        /// Gift identification
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Gift cost
        /// </summary>
        public decimal Price { get; set; }

        public override string ToString()
        {
            return $"{Name} {Price}";
        }

        public override bool Equals(object obj)
        {
            if (obj == null || GetType() != obj.GetType())
            {
                return false;
            }

            Gift gift = obj as Gift;

            return gift.Price.Equals(Price) && gift.Name.Equals(Name);
        }
        
        public override int GetHashCode()
        {
            return Name.GetHashCode() * Price.GetHashCode() * 7;
        }
    }
}
