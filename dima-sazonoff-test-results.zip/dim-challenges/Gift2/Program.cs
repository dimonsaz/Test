using System;
using System.IO;
using System.Linq;

namespace Gift2
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Input validations
            if (args.Length != 2)
            {
                Console.WriteLine("command line args: <file_path> <max_cost>");
                return;
            }

            string filePath = args[0].Trim();
            if (!File.Exists(filePath))
            {
                Console.WriteLine("File '" + filePath + "' is not exist!");
                return;
            }

            if (!Decimal.TryParse(args[1].Trim(), out decimal maxPrice))
            {
                Console.WriteLine("Cannot parse max price number: " + args[1] + "'");
                return;
            }
            Console.WriteLine("Find gifts for max price: " + maxPrice);
            #endregion

            char[] giftDelimiters = new[] { ',' };
            var gifts = File.ReadLines(filePath)
                .Select(l =>
                {
                    return ParseGiftFromString(l, giftDelimiters);
                })
                .ToArray();

            try
            {
                //BruteForce(filePath, maxPrice);
                Optimized(gifts, maxPrice);
            }
            catch (Exception e)
            {
                Console.WriteLine("Error " + e);
            }
        }

        // optimized  time complexity: O(n)
        // One pointer is at start and second at end and they walk towards each other till meet and return result
        private static void Optimized(Gift[] gifts, decimal maxPrice)
        {
            int idx1 = -1, idx2 = -1;
            decimal max = 0;
            int i = 0;               // --- index of first gift
            int j = gifts.Length - 1; // ---last gift

            while (i < j)
            {
                decimal sum = gifts[i].Price + gifts[j].Price;
                if (sum > max && sum <= maxPrice && i != j)
                {
                    max = maxPrice;
                    idx1 = i;
                    idx2 = j;
                    i++;
                }
                else
                    j--;
            }
            if( idx1<0 ||idx2<0)
                Console.WriteLine("Not possible.");
            else
                Console.WriteLine(gifts[idx1] + " " + gifts[idx2]);
        }

        // Time Complexity: O(n^2)
        private static void BruteForce(Gift[] gifts, decimal maxPrice)
        {
            for (int i = gifts.Length - 1; i >= 0; i--)
            {
                if (gifts[i].Price > maxPrice)
                    continue;
                for (int j = i - 1; j >= 0; j--)
                {
                    if (gifts[i].Equals(gifts[j]))
                        continue;

                    if (gifts[i].Price + gifts[j].Price <= maxPrice)
                    {
                        Console.WriteLine($"{gifts[i]}, {gifts[j]}");
                        return;
                    }
                }
            }
            Console.WriteLine("Not possible.");
        }

        private static Gift ParseGiftFromString(string giftString, char[] delimiters)
        {
            string[] elements = giftString.Split(delimiters, StringSplitOptions.RemoveEmptyEntries);

            try
            {
                return new Gift { Name = elements[0].Trim(), Price = decimal.Parse(elements[1].Trim()) };
            }
            catch (Exception)
            {
                return null;
            }
        }
    }
}
