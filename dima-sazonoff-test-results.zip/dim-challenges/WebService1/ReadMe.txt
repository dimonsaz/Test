1. webserver testing:

» curl -H "Content-Length:0" -X POST http://localhost:61975/messages/hello
"2CF24DBA5FB0A30E26E83B2AC5B9E29E1B161E5C1FA7425E73043362938B9824"%    

» curl http://localhost:61975/messages/2CF24DBA5FB0A30E26E83B2AC5B9E29E1B161E5C1FA7425E73043362938B9824                                       
"hello"%            

