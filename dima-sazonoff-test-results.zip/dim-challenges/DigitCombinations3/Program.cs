using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DigitCombinations
{
    class Program
    {
        static void Main(string[] args)
        {
            if (args.Length == 0)
            {
                Console.WriteLine("usage: ./DigitCombinations.exe <pattern>\nfor example: ./DigitCombinations.exe 01x00x01");
                return;
            }

            string input = args[0].ToLower();
            char specialChar = 'x';
            int countX = input.Count(c => c == specialChar);
            //permutations(input, specialChar, countX);
            noMemoryAlloc(input, countX);
        }

        private static void noMemoryAlloc(string input, int countX)
        {
            int number = 0;
            while (true)
            {
                string binaryNumber = Convert.ToString(number++, 2);
                if (binaryNumber.Length > countX)
                {
                    break;
                }
                else
                {
                    while (binaryNumber.Length < countX)
                    {
                        binaryNumber = binaryNumber.Insert(0, "0");
                    }
                    int lastIndex = 0;
                    string currentString = (string)input.Clone();
                    for (int i = 0; i < countX; i++)
                    {
                        int findIndex = currentString.IndexOf('x', lastIndex);
                        currentString = currentString.Insert(findIndex, binaryNumber[i].ToString());
                        currentString = currentString.Remove(findIndex + 1, 1);
                    }
                    Console.WriteLine(currentString);
                }
            }
        }

        private static void permutations(string input, char specialChar, int degree)
        {
            int size = (int)Math.Pow(2, degree);

            string[] rangeBinaryRepresentation
                = GetRangeBinaryRepresentation(0, size)
                 .Select(s => s.PadLeft(degree, '0'))
                 .ToArray();
            var result = new List<string>();
            for (int i = 0; i < size; i++)
            {
                var tempInp = new StringBuilder(input);
                for (int j = 0; j < degree; j++)
                {
                    int indexOfx = tempInp.ToString().IndexOf(specialChar);
                    tempInp[indexOfx] = rangeBinaryRepresentation[i][j];
                }
                result.Add(tempInp.ToString());
            }
            result.ToList().ForEach(Console.WriteLine);
        }

        private static IEnumerable<string> GetRangeBinaryRepresentation(int rangeStart, int rangeEnd)
        {
            return Enumerable.Range(rangeStart, rangeEnd)
                .Select(n => Convert.ToString(n, 2));
        }
    }
}
